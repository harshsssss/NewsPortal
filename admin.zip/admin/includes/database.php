<?php
  $con=mysqli_connect("localhost","root","","news") or die("Not connect to mysql")
?>