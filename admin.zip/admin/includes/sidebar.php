<div class="list-group mt-2">
  <a href="?con=category" class="list-group-item list-group-item-action active">
    Category
  </a>
  <a href="?con=news" class="list-group-item list-group-item-action">News</a>
  <a href="?con=feedback" class="list-group-item list-group-item-action">Feedback</a>
  
</div>