<?php 
 session_start();
 include("includes/database.php");//include db file 
 $sid=$_SESSION['sid'];
 if(empty($sid))
 {
    header("location:index.php");
 }
?>
<!doctype html>
<html>
   <head>
      <?php include('includes/boot-head.php');?>
   </head>
  <body>
     <main>
        <header>
        <?php include('includes/nav.php');?>
        </header>
        <section class="row container">
           <div class="col-sm-4">
           <?php include('includes/sidebar.php');?>
           </div>
           <div class="col-sm-8">
             <?php 
                if(!empty($_GET['con']))
                {
                    switch($_GET['con']){
                        case 'changepass':include('changepass.php');
                        break;
                        case 'category':include('category.php');
                        break;
                        case 'news':include('news.php');
                        break;
                        case 'feedback':include('feedback.php');
                        break;
                    }
                }
             ?>
           </div>
        </section>
     </main> 
     <?php include('includes/boot-foot.php');?>
  </body>
</html>