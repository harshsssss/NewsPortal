<?php 
 include("includes/database.php");//include db file 
 extract($_POST);
 if(isset($sub)){
    if(empty($email) || empty($password)){
      $errMsg="Plz fill blank fields";
    }
    else {
        $password=sha1($password);
         $sel=mysqli_query($con,"select email,password from admin where email='$email' and password='$password'");
         $arr=mysqli_fetch_array($sel);
         //if(mysqli_num_rows($sel)>0)
         if($arr['email']==$email && $arr['password']==$password){
               session_start();
               $_SESSION['sid']=$email;
               header("location:dashboard.php");
         }
         else {
            $errMsg="Enter correct email or password";
         }
    }
 }
?>
<!doctype html>
<html>
   <head>
      <?php include('includes/boot-head.php');?>
   </head>
  <body>
     <main>
        <header class="jumbotron">
          <h1 class="text-center"> Admin Panel </h1>
        </header>
        <section class="container">
        <?php 
          if(!empty($errMsg))
          {
             ?>
            <div class="alert alert-danger"><?= $errMsg;?></div>
             <?php 
          }
        ?>
          <form method="post">
             <div class="form-group">
                <label> Email </label>
                <input type="email" name="email" class="form-control"/>
             </div>
             <div class="form-group">
                <label> Password </label>
                <input type="password" name="password" class="form-control"/>
             </div>
             <div class="form-group">
              <input type="checkbox" name="check"/>
              <label> Remember Me </label>
             </div>
             <input type="submit" value="Login" name="sub" class="btn btn-info"/>
          </form>
        </section>
     </main>
     <?php include('includes/boot-foot.php');?>
  </body>
</html>