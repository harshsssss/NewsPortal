<?php 
  extract($_POST);
  if(isset($sub)){
      if(empty($op) || empty($np) || empty($cp)){
          $errMsg="Please fill blank fields";
      }
      else {
          if($np==$cp){
              $sel=mysqli_query($con,"select password from admin where email='$sid'");
              $arr=mysqli_fetch_assoc($sel);
              if($arr['password']==sha1($op)){
                 $np=sha1($np);
                 if(mysqli_query($con,"update admin set password='$np' where email='$sid'"))
                 {
                     $succMsg="Password Changed";
                 }
                 else{
                     $errMsg="Password is not changed";
                 }
              }
              else {
                  $errMsg="Enter correct old password";
              }
          }
          else {
              $errMsg="New pass and Con pass is not match";
          }
      }
  }
?>
<h1> Change Password</h1>
<form method="post">
<?php 
          if(!empty($errMsg))
          {
             ?>
            <div class="alert alert-danger"><?= $errMsg;?></div>
             <?php 
          }
          if(!empty($succMsg))
          {
             ?>
            <div class="alert alert-success"><?= $succMsg;?></div>
             <?php 
          }
        ?>
  <div class="form-group">
    <label> Old Password </label>
    <input type="password" name="op" class="form-control"/>
  </div>
  <div class="form-group">
    <label> New Password </label>
    <input type="password" name="np" class="form-control"/>
  </div>
  <div class="form-group">
    <label> Confirm Password </label>
    <input type="password" name="cp" class="form-control"/>
  </div>
  <input type="submit" name="sub" value="Submit"/>
</form>